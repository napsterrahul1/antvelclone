<div class="navbar-wrapper container">
	{!! Breadcrumbs::render('productDetail', $product) !!}
</div>