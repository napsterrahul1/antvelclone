<div class="row">&nbsp;</div>
<div class="row">
	<div class="col-md-12">
		<label class="control-label">{{ trans('company.description')}}:</label>
		{!! Form::textarea('description',null,['class'=>'form-control']) !!}
	</div>
	<div class="col-md-12">&nbsp;</div>
	<div class="col-md-12">
		<label class="control-label">{{ trans('company.keywords')}}:</label>
		{!! Form::textarea('keywords',null,['class'=>'form-control']) !!}
	</div>
	
</div>
<div class="row">&nbsp;</div>