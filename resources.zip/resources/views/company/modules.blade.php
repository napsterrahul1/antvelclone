<div class="page-header">
	<h4>{{ trans('company.modules')}}</h4>
</div>
<div class="row">
	<div class="col-md-12">
		<div class="checkbox">
			<label>
				<input type="checkbox"> {{ trans('globals.freeproducts')}}
			</label>
		</div>
	</div>
</div>