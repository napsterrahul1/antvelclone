<?php

return [
    'female' => 'female',
    'male'   => 'male',
];
