<?php

return [

    'contact'             => 'Холбоо барих',
    'name'                => 'Нэр',
    'email'               => 'И-мэйл',
    'message'             => 'Зурвас',
    'name_placeholder'    => 'Таны нэр',
    'email_placeholder'   => 'И-мэйл оруулна уу',
    'message_placeholder' => 'Хүсэлтээ бичнэ үү',
    'contact_us'          => 'Холбоо барих',
    'thanks'              => 'Бидэнтэй холбогдсон таньд баярлалаа! Удахгүй бид таньд хариу илгээх болно.',
    'type_of_request'     => 'Гарчиг',

];
