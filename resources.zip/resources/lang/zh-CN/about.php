<?php

return [

    'contact'             => '联系我们',
    'name'                => '名字',
    'email'               => '邮箱',
    'message'             => '信息',
    'name_placeholder'    => '请输入全名',
    'email_placeholder'   => '您的邮箱',
    'message_placeholder' => '我们可以怎样帮助您？',
    'contact_us'          => '联系我们！',
    'thanks'              => '谢谢！您很快会收到我们的答复！',
    'type_of_request'     => '主题',

];
