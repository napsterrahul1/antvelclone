<?php

return [

    'contact'             => 'Contact Us',
    'name'                => 'Name',
    'email'               => 'Email',
    'message'             => 'Message',
    'name_placeholder'    => 'Type your full name here',
    'email_placeholder'   => 'We need your email to be on touch',
    'message_placeholder' => 'Tell us what we can help you with',
    'company_placeholder' => 'Tell us about company name and Address',
    'contact_us'          => 'Contact Us!',
    'other_policies'          => 'Other Policies!',
    'user_agreement'          => 'User Agreement!',
    'Submit'          => 'Submit',
    'thanks'              => 'Thanks for contacting us! Soon you will receive our response',
    'type_of_request'     => 'Subject heading',

];
