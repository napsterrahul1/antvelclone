<?php

return [

    'contact'             => 'Contato',
    'name'                => 'Nome',
    'email'               => 'Email',
    'message'             => 'Mensagem',
    'name_placeholder'    => 'Escreva seu nome completo aqui',
    'email_placeholder'   => 'Nós precisamos do seu email para entrarmos em contato',
    'message_placeholder' => 'O que podemos fazer por você',
    'contact_us'          => 'Contate-nos!',
    'thanks'              => 'Muito obrigado por nos contatar! Responderemos em breve!',
    'type_of_request'     => 'Título',

];
