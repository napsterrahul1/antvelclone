<?php

namespace app;

/*
 * Antvel - PayPal Order Model
 *
 * @author  Gustavo Ocanto <gustavoocanto@gmail.com>
 */

use Illuminate\Database\Eloquent\Model;

class PaypalOrder extends Model
{
    protected $table = 'paypal_orders';
}
