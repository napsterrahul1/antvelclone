<?php

namespace app\Http\Controllers;

/*
 * Antvel - Company CMS Controller
 *
 * @author  Gustavo Ocanto <gustavoocanto@gmail.com>
 */

use App\Company;
use App\ContactUs;
use App\Http\Controllers\Controller;
use App\Http\Requests\ContactFormRequest;
use Illuminate\Http\Request;
use App\Order;
use app\User;
use Illuminate\Support\Facades\Mail;

class AboutController extends Controller
{
    public function create()
    {
        $kind_of_request = ['contact' => trans('company.contact'),
                    'sales'           => trans('company.sales'),
                    'support'         => trans('company.support'), ];

        $panel = ['center' => ['width' => '12']];

        return view('about.contact', compact('panel', 'kind_of_request'));
    }
    public function contact()
    {
//        $kind_of_request = ['contact' => trans('company.contact'),
//                    'sales'           => trans('company.sales'),
//                    'support'         => trans('company.support'), ];
        $kind_of_request = [
                             'Enquiry'  => 'Enquiry',
                             'Feedback' => 'Feedback',
                             'Complaints'  => 'Complaints',
                             'Reviews'  => 'Reviews',
                            ];

        $panel = ['center' => ['width' => '12']];
        
        return view('about.contactus', compact('panel', 'kind_of_request'));
    }

    public function store(ContactFormRequest $request)
    {
        $company = Company::select('contact_email',
                                  'sales_email',
                                  'support_email',
                                  'website_name')
                         ->find(1)
                         ->toArray();

//        $from_address = $company[$request->get('type_of_request').'_email'];
        $from_address = $company['contact_email'];

        $name = $request->get('name');
        $email = $request->get('email');
        $number = $request->get('number');
        $message_ = $request->get('message');
        $type = $request->get('type_of_request');

        $contactUs = new ContactUs();
        $contactUs->name = $name;
        $contactUs->email = $email;
        $contactUs->number = $number;
        $contactUs->message = $message_;
        $contactUs->type_of_request = $type;
        $contactUs->save();
//        dump($request->get('type_of_request'));
//        dd('enry done...complete the email send');

        $title = trans('company.email_title_'.$request->get('type_of_request'));
        $thanks = trans('company.email_thanks_'.$request->get('type_of_request'));
//        return view('emails.contact', compact('thanks', 'title', 'name', 'email', 'message_','number'));
        Mail::send('emails.contact', compact('thanks', 'title', 'name', 'email', 'message_','number'),
            function ($message) use ($request, $company, $from_address, $email) {
                $message->from($from_address, $company['website_name']);
                $message->to($email)
                        ->cc($from_address)
                        ->subject(trans('about.contact').' :: '.$company['website_name']);
            });

        $admin = User::where('role','admin')->first();
        Mail::send('emails.contact', compact('thanks', 'title', 'name', 'email', 'message_','number'),
            function ($message) use ($request, $company, $from_address, $admin) {
                $message->from($from_address, $company['website_name']);
                $message->to($admin->email)
                    ->cc($from_address)
                    ->subject(trans('about.contact').' :: '.$company['website_name']);
            });
        return \Redirect::route('contactus')->with('message', $thanks);
    }
    public function contactList(Request $request)
    {

        $user = \Auth::user();

        $where_field = $user->role == 'person' ? 'user_id' : 'seller_id';
        $condition = '=';
        if(($user->role == 'admin') || ($user->role == 'subadmin')) {
            $where_field = 'user_id';
            $condition = '!=';
        }
        $filter = $request->get('filter') ? explode('*', $request->get('filter')) : [];

        $dateFrom = $request->get('dateFrom') ? $request->get('dateFrom') : '';

        $dateTo = $request->get('dateTo') ? $request->get('dateTo') : '';

        if ($dateFrom == '' && isset($filter[0])) {
            $dateFrom = $filter[0];
        }

        if ($dateTo == '' && isset($filter[1])) {
            $dateTo = $filter[1];
        }

//        $openOrders = Order::
//        where($where_field,$condition,$user->id)
//            ->with('user.profile')
//            ->ofType('order')
//            ->whereIn('status', ['open', 'pending', 'sent'])
//            ->orderBy('created_at', 'desc')
//            ->ofDates($dateFrom, $dateTo)
//            ->paginate(20);
        $contactUsEnquiry = ContactUs::where('type_of_request', '=', 'Enquiry')
            ->get();

        $contactUsFeedback = ContactUs::where('type_of_request', '=', 'Feedback')
            ->get();

        $contactUsComplaints = ContactUs::where('type_of_request', '=', 'Complaints')
            ->get();

        $contactUsReviews = ContactUs::where('type_of_request', '=', 'Reviews')
            ->get();


//        $closedOrders = Order::
//        where($where_field,$condition,$user->id)
//            ->with('user.profile')
//            ->ofType('order')
//            ->ofStatus('closed')
//            ->ofDates($dateFrom, $dateTo)
//            ->paginate(20);
//
//        $cancelledOrders = Order::
//        where($where_field,$condition,$user->id)
//            ->with('user.profile')
//            ->ofType('order')
//            ->ofStatus('cancelled')
//            ->ofDates($dateFrom, $dateTo)
//            ->paginate(20);
//
//        $unRate = Order::
//        where($where_field,$condition,$user->id)
//            ->with('details')
//            ->with('user.profile')
//            ->ofType('order')
//            ->whereIn('status', ['received', 'closed'])
//            ->whereNull('rate')
//            ->ofDates($dateFrom, $dateTo)
//            ->paginate(20);

        $panel = [
            'left'   => ['width' => '2', 'class' => 'user-panel'],
            'center' => ['width' => '10'],
        ];

        $select = $request->get('show') ? $request->get('show') : '';
        return view('about.contactList', compact('panel', 'contactUsEnquiry', 'contactUsFeedback', 'contactUsComplaints', 'select', 'contactUsReviews', 'dateFrom', 'dateTo'));
    }

    public function about($tab = 'about')
    {
        return view('about.aboutus', compact('tab'));
    }

    public function refunds()
    {
        $tab = 'refund';
        return view('about.index', compact('tab'));
    }

    public function privacy()
    {
        $tab = 'privacy';
        return view('about.privacy_policies');
    }

    public function terms()
    {
        $tab = 'terms';
        return view('about.termsAndConditions', compact('tab'));
    }
    public function otherPolicies()
    {
        return view('about.other_policies');
    }
    public function userAgreement()
    {
        return view('about.user_agreement');
    }
}
